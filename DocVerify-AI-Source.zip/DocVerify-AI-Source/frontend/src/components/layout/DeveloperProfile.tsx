import React, { useState, useRef, useEffect } from 'react';
import { X, Code2, ShieldCheck, Cpu, Database } from 'lucide-react';

export const DeveloperProfile: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  // Close on Escape key
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
        buttonRef.current?.focus();
      }
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [isOpen]);

  // Close on outside click
  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (
        isOpen &&
        modalRef.current &&
        !modalRef.current.contains(e.target as Node) &&
        !buttonRef.current?.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, [isOpen]);

  return (
    <div className="relative inline-block">
      {/* AICORE Trigger Button */}
      <button
        ref={buttonRef}
        onClick={() => setIsOpen((prev) => !prev)}
        aria-expanded={isOpen}
        aria-haspopup="dialog"
        aria-label="View AICORE project information"
        className={`
          inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold
          border transition-all duration-200 cursor-pointer
          focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-1 focus:ring-offset-slate-900
          ${isOpen
            ? 'bg-cyan-950/70 border-cyan-500/70 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
            : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800 hover:border-cyan-500/50 hover:text-cyan-300'
          }
        `}
      >
        <Code2 className="w-3.5 h-3.5 text-cyan-400" />
        <span>AICORE</span>
      </button>

      {/* Modal Card with Backdrop */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
          <div
            ref={modalRef}
            role="dialog"
            aria-modal="true"
            aria-label="AICORE project information"
            className={`
              relative w-full max-w-[360px] sm:max-w-[390px]
              bg-[#080d1a] border border-[#1a253c]
              rounded-[28px] shadow-[0_20px_60px_rgba(0,0,0,0.85)]
              p-6 sm:p-7
              text-center
              animate-in zoom-in-95 duration-200
            `}
          >
            {/* Close Button in top right */}
            <button
              onClick={() => setIsOpen(false)}
              aria-label="Close project information"
              className="absolute top-4 right-4 p-1.5 rounded-full text-slate-500 hover:text-slate-200 hover:bg-slate-800/60 transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Logo */}
            <div className="flex justify-center mb-4">
              <div className="relative group">
                <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-cyan-500 via-teal-400 to-cyan-500 opacity-70 blur-md group-hover:opacity-90 transition duration-300" />
                <div className="relative w-24 h-24 rounded-full p-[2.5px] bg-gradient-to-b from-cyan-400 via-teal-500 to-cyan-600 shadow-xl overflow-hidden">
                  <div className="w-full h-full rounded-full bg-gradient-to-br from-indigo-950 to-slate-900 flex items-center justify-center text-cyan-400">
                    <Cpu className="w-11 h-11" />
                  </div>
                </div>
              </div>
            </div>

            {/* Name + Code Badge */}
            <div className="flex items-center justify-center gap-1.5">
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-wide">
                AICORE
              </h2>
              <span className="inline-flex items-center justify-center text-cyan-400 bg-cyan-950/60 border border-cyan-800/80 rounded px-1.5 py-0.5 text-[11px] font-mono font-bold">
                {'</>'}
              </span>
            </div>

            {/* Role / Subtitle */}
            <div className="mt-1">
              <span className="text-[11px] font-extrabold tracking-wider font-mono text-cyan-400 uppercase">
                AI-POWERED DOCUMENT SCREENING
              </span>
            </div>

            {/* Bio Description */}
            <p className="mt-2 text-xs text-slate-400 leading-relaxed max-w-[300px] mx-auto">
              AICORE is the development team behind DocVerify AI — an AI-driven
              fake identity and document screening system for border security.
            </p>

            {/* Capability List */}
            <div className="mt-5 space-y-2 text-left">
              {[
                { icon: <ShieldCheck className="w-4 h-4" />, title: 'Identity Screening', desc: 'AI-assisted verification for PS 26188' },
                { icon: <Cpu className="w-4 h-4" />, title: 'Pretrained AI Models', desc: 'OCR, face matching & forgery detection' },
                { icon: <Database className="w-4 h-4" />, title: 'Forensics & Risk Engine', desc: 'ELA, stamp & metadata analysis' },
              ].map((item) => (
                <div
                  key={item.title}
                  className="flex items-center gap-3 w-full px-3.5 py-2.5 rounded-xl bg-[#0d1424]/90 border border-[#18233c] hover:border-cyan-500/40 transition-all duration-150"
                >
                  <div className="w-9 h-9 rounded-lg bg-[#131c30] border border-slate-800/90 flex items-center justify-center text-cyan-400 flex-shrink-0">
                    {item.icon}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-100 leading-tight">{item.title}</div>
                    <div className="text-[11px] text-slate-400 font-mono truncate mt-0.5">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
