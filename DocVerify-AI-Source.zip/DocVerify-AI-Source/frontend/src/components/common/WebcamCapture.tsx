import React, { useEffect, useRef, useState } from 'react';
import { Camera, X, AlertTriangle, ScanLine, RefreshCw } from 'lucide-react';

interface WebcamCaptureProps {
  onCapture: (file: File, dataUrl: string) => void;
  onClose: () => void;
  title?: string;
  hint?: string;
  facingMode?: 'environment' | 'user';
}

export const WebcamCapture: React.FC<WebcamCaptureProps> = ({
  onCapture,
  onClose,
  title = 'Live Webcam Capture',
  hint = 'Position the object in the frame and press Capture.',
  facingMode = 'environment',
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [starting, setStarting] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode,
            width: { ideal: 1920 },
            height: { ideal: 1080 },
          },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        setStarting(false);
      } catch {
        if (!cancelled) {
          setCameraError(
            'Camera access is unavailable or permission was denied. Close this panel and use file upload instead.'
          );
          setStarting(false);
        }
      }
    };

    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError(
        'Your browser does not support webcam capture on this connection. Use file upload instead.'
      );
      setStarting(false);
      return;
    }

    startCamera();

    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    };
  }, [facingMode]);

  const handleCapture = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob(
      (blob) => {
        if (!blob) return;
        const file = new File([blob], `live-capture-${Date.now()}.jpg`, { type: 'image/jpeg' });
        onCapture(file, canvas.toDataURL('image/jpeg'));
      },
      'image/jpeg',
      0.92
    );
  };

  const handleClose = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    onClose();
  };

  return (
    <div className="rounded-lg overflow-hidden border border-slate-700 bg-slate-950/90">
      <div className="flex items-center justify-between px-3 py-2 bg-slate-900 border-b border-slate-800">
        <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
          <Camera className="w-3.5 h-3.5 text-indigo-400" />
          {title}
        </span>
        <button
          onClick={handleClose}
          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
          title="Close Camera"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="relative aspect-[4/3] bg-black flex items-center justify-center">
        {cameraError ? (
          <div className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto mb-3" />
            <p className="text-xs text-amber-200/90 leading-relaxed max-w-xs mx-auto">{cameraError}</p>
            <button
              onClick={handleClose}
              className="mt-4 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer"
            >
              Close Camera Panel
            </button>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-contain"
            />
            {starting && (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-950/60">
                <RefreshCw className="w-6 h-6 text-indigo-400 animate-spin" />
              </div>
            )}
            <div className="absolute inset-4 border-2 border-dashed border-indigo-400/50 rounded-lg pointer-events-none flex items-center justify-center">
              <span className="text-[10px] font-mono text-indigo-300 bg-slate-950/70 px-2 py-0.5 rounded">
                ALIGN & CAPTURE
              </span>
            </div>
          </>
        )}
      </div>

      {!cameraError && (
        <div className="px-3 py-2.5 flex items-center justify-between gap-2 bg-slate-900 border-t border-slate-800">
          <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
            <ScanLine className="w-3.5 h-3.5 text-slate-500" />
            {hint}
          </div>
          <button
            onClick={handleCapture}
            disabled={starting}
            className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Camera className="w-4 h-4" />
            Capture Frame
          </button>
        </div>
      )}
    </div>
  );
};