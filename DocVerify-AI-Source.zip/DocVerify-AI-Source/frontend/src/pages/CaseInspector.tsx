import React, { useState, useEffect } from 'react';
import {
  AlertOctagon, Download, Eye, FileText, Camera, Lock,
  ArrowLeft, RefreshCw, Check, ShieldAlert, FileCheck, AlertTriangle, Lightbulb
} from 'lucide-react';
import { getScreeningApi, submitDecisionApi } from '../services/api';
import type { ScreeningDetail } from '../types';
import { RiskBadge } from '../components/common/RiskBadge';
import { StatusBadge } from '../components/common/StatusBadge';

interface CaseInspectorProps {
  screeningId: string;
  onBack: () => void;
}

export const CaseInspector: React.FC<CaseInspectorProps> = ({ screeningId, onBack }) => {
  const [screening, setScreening] = useState<ScreeningDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [viewMode, setViewMode] = useState<'ORIGINAL' | 'ELA' | 'PHOTO'>('ORIGINAL');
  const [officerNotes, setOfficerNotes] = useState<string>('');
  const [submittingDecision, setSubmittingDecision] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const loadScreening = async () => {
    setLoading(true);
    try {
      const data = await getScreeningApi(screeningId);
      setScreening(data);
      setOfficerNotes(data.officer_notes || '');
    } catch (err: any) {
      setError(err.message || 'Failed to load screening dossier');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadScreening();
  }, [screeningId]);

  const handleDecision = async (status: string) => {
    if (!officerNotes.trim()) {
      setError('Please provide officer notes and justification before submitting determination.');
      return;
    }
    setSubmittingDecision(true);
    setError(null);
    try {
      const updated = await submitDecisionApi(screeningId, status, officerNotes);
      setScreening(updated);
      setSuccessMessage(`Official determination recorded: ${status}`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      setError(err.message || 'Failed to submit decision');
    } finally {
      setSubmittingDecision(false);
    }
  };

  const handleDownloadReport = async () => {
    try {
      const token = localStorage.getItem('sih_auth_token');
      const res = await fetch(`/api/screenings/${screeningId}/report`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) throw new Error('Failed to generate PDF dossier');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `screening_dossier_${screeningId}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err: any) {
      setError(err.message || 'Failed to download PDF dossier');
    }
  };

  if (loading) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-16 text-center">
        <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin mx-auto mb-3" />
        <h2 className="text-sm font-semibold text-slate-200">Loading AI Forensic Dossier...</h2>
        <p className="text-xs text-slate-500 font-mono mt-1">Screening ID: {screeningId}</p>
      </div>
    );
  }

  if (error && !screening) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center">
        <AlertOctagon className="w-8 h-8 text-rose-400 mx-auto mb-2" />
        <h2 className="text-sm font-bold text-slate-200">Failed to Load Case</h2>
        <p className="text-xs text-slate-400 mt-1">{error}</p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 rounded-lg bg-slate-800 text-xs font-semibold text-slate-200 hover:bg-slate-700"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  const doc = screening?.document;
  const ext = screening?.extracted_fields;
  const mrz = screening?.mrz_result;
  const tamper = screening?.tampering_result;
  const face = screening?.face_result;
  const reg = screening?.registry_check;
  const risk = screening?.risk_assessment;
  const forge = screening?.forge_result;
  const stamp = screening?.stamp_result;
  const validation = screening?.validation_result;

  const docImageUrl = doc?.file_path ? `${doc.file_path}` : '';
  const elaImageUrl = tamper?.ela_heatmap_path ? `${tamper.ela_heatmap_path}` : docImageUrl;
  const docPhotoUrl = face?.doc_face_crop_path ? `${face.doc_face_crop_path}` : docImageUrl;
  const livePhotoUrl = face?.live_face_path ? `${face.live_face_path}` : null;

  type ExplPoint = { text: string; tone: 'good' | 'bad' | 'info' };
  const pct = (n?: number) => `${Math.round((n ?? 0) * 100)}%`;

  const buildExplanation = (): { verdict: string; tone: 'good' | 'bad' | 'info'; points: ExplPoint[] } => {
    const points: ExplPoint[] = [];

    // 1. Registry checks
    if (reg?.check_status && reg.check_status !== 'CLEAR') {
      points.push({
        text: `Document matched a security registry — ${reg.matched_registry || reg.check_status}. This is a critical identity-signal flag.`,
        tone: 'bad',
      });
    } else if (reg?.check_status === 'CLEAR') {
      points.push({
        text: 'No match found in Interpol SLTD / watchlist registries — identity record is clear.',
        tone: 'good',
      });
    }

    // 2. MRZ / checksums
    if (mrz?.mrz_detected) {
      if (mrz?.all_checksums_valid) {
        points.push({
          text: 'MRZ band present and all ICAO 9303 7-3-1 check digits (document number, DOB, expiry, composite) validate — encoded data is internally consistent.',
          tone: 'good',
        });
      } else {
        points.push({
          text: 'MRZ band check digits FAIL — the encoded data is inconsistent with the printed fields, a strong sign of tampering or re-encoding.',
          tone: 'bad',
        });
      }
      if (mrz?.matches_viz_fields === false) {
        points.push({
          text: 'Printed (visual) text does not match the machine-readable MRZ characters — fields were not printed from the same source.',
          tone: 'bad',
        });
      }
    } else {
      points.push({
        text: 'This document type carries no MRZ band — verification was performed on the OCR text and visual field consistency instead.',
        tone: 'info',
      });
    }

    // 3. Date / validity rules
    if (validation) {
      if (validation.is_expired) {
        points.push({ text: 'The document is expired — it is no longer valid for travel/entry.', tone: 'bad' });
      }
      if (validation.is_future_issue_date) {
        points.push({ text: 'The recorded issue date is in the future — chronologically impossible, indicating a forged or altered field.', tone: 'bad' });
      }
      if (validation.is_valid_age === false) {
        points.push({ text: 'Holder age / date of birth is inconsistent with the issue timeline (impossible age anomaly).', tone: 'bad' });
      }
      if (validation.is_valid_doc_number_format === false) {
        points.push({ text: 'Document number does not follow the issuing country’s standard syntax.', tone: 'bad' });
      }
      if (validation.passed_all_rules) {
        points.push({ text: 'Date fields and document number pass all format/validity rules — chronologically consistent and currently valid.', tone: 'good' });
      }
    }

    // 4. Tampering forensics (ELA, splicing, metadata)
    if (tamper) {
      if ((tamper.ela_anomaly_score ?? 0) >= 0.2) {
        points.push({
          text: `Error Level Analysis found ${pct(tamper.ela_anomaly_score)} compression disparity — evidence of digital modification or spliced content.`,
          tone: 'bad',
        });
      }
      if ((tamper.photo_splicing_score ?? 0) >= 0.45) {
        points.push({ text: 'Photo perimeter discontinuity detected around the portrait — likely replacement of the original photo.', tone: 'bad' });
      }
      if (tamper.metadata_manipulation_flag) {
        points.push({ text: 'Image metadata contains editing-software signatures — the file was re-processed after original capture.', tone: 'bad' });
      }
      if (!tamper.has_tampering_evidence && (tamper.ela_anomaly_score ?? 0) < 0.2) {
        points.push({ text: 'Forensic analysis found no compression anomalies, photo splicing, or metadata tampering evidence.', tone: 'good' });
      }
    }

    // 5. Face biometrics
    if (face) {
      if (face.match_status === 'MATCH') {
        points.push({ text: `Live portrait matches the document photo with ${Math.round(face.similarity_score ?? 0)}% similarity — same person.`, tone: 'good' });
      } else if (face.match_status === 'MISMATCH') {
        points.push({ text: 'Live portrait does NOT match the document holder photo — impersonation risk.', tone: 'bad' });
      } else if (face.match_status === 'INCONCLUSIVE' || face.match_status === 'LOW_QUALITY') {
        points.push({ text: 'Face comparison was degraded or inconclusive — not a forgery flag by itself, but manual verification is advised.', tone: 'info' });
      } else if (face.match_status === 'NO_LIVE_CAPTURE') {
        points.push({ text: 'No live capture was provided, so face comparison was skipped — not treated as a forgery signal.', tone: 'info' });
      }
    }

    // 6. Deep-learning forgery model
    if (forge) {
      if (forge.verdict === 'FORGED' && forge.model_hit) {
        points.push({
          text: `Deep-learning forgery model (${forge.model_name || 'document-forgery detector'}) classified the content as FORGED with ${pct(forge.forge_probability)} confidence.`,
          tone: 'bad',
        });
      } else if (forge.verdict === 'AUTHENTIC' && forge.risk < 0.45) {
        points.push({
          text: `Deep-learning forgery model found no forgery traits — classified as AUTHENTIC (${pct(forge.forge_probability)} authenticity probability).`,
          tone: 'good',
        });
      } else {
        points.push({
          text: `Deep-learning forgery model result was borderline (risk ${pct(forge.risk)}) — treated as a caution signal.`,
          tone: 'info',
        });
      }
    }

    // 7. Stamp / seal forensics
    if (stamp) {
      if (stamp.suspicious && (stamp.forgery_risk ?? 0) >= 0.5) {
        points.push({
          text: `Official stamp/seal forensics flagged ${stamp.stamp_count ?? 0} anomalous ink regions with abnormal compression residual (risk ${pct(stamp.forgery_risk)}) — possible forged seal.`,
          tone: 'bad',
        });
      } else {
        points.push({ text: 'No suspicious official stamps or seals detected — ink regions appear consistent.', tone: 'good' });
      }
    }

    // Verdict line
    const anyFactor = (risk?.contributing_factors_json?.length || 0) > 0;
    if ((risk?.risk_level || 'LOW') === 'LOW' && !anyFactor) {
      return {
        verdict: 'AUTHENTIC — No Forgery Indication',
        tone: 'good',
        points,
      };
    }
    if ((risk?.risk_level || 'LOW') === 'LOW' || (risk?.risk_level || 'LOW') === 'MANUAL_REVIEW') {
      return {
        verdict: 'PROBABLY AUTHENTIC — Needs Officer Review',
        tone: 'info',
        points,
      };
    }
    return {
      verdict: 'LIKELY FORGED / HIGH RISK',
      tone: 'bad',
      points,
    };
  };

  const explanation = buildExplanation();

  return (
    <div className="space-y-6">
      {/* Top Dossier Header Bar */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div>
              <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                  AI-ASSISTED ANALYSIS
                </span>
                <span className="text-xs font-mono text-slate-400">
                  CASE #{screening?.id.slice(0, 8)}
                </span>
                <span className="text-slate-600">•</span>
                <span className="text-xs font-mono text-slate-400">
                  DOC: {ext?.document_number || 'N/A'}
                </span>
                <StatusBadge status={screening?.status || 'IN_PROGRESS'} size="sm" />
              </div>
              <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
                <span>{ext?.full_name || 'EVALUATION SUBJECT'}</span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  NAT: {ext?.nationality || 'IND'}
                </span>
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <RiskBadge
              level={risk?.risk_level || 'LOW'}
              score={risk?.risk_score}
              size="lg"
            />

            <button
              onClick={handleDownloadReport}
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold shadow-sm transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              <span>Download PDF Dossier</span>
            </button>
          </div>
        </div>
      </div>

      {successMessage && (
        <div className="p-3 rounded-lg bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2 font-medium">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Main 3-Column Inspection Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* COLUMN 1: Visual Forensics & Interactive Image Viewer (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-indigo-400" />
                <span>Forensic Document Viewer</span>
              </h2>
              <span className="text-[10px] font-mono text-slate-400">
                SHA-256: {doc?.sha256_hash.slice(0, 10)}...
              </span>
            </div>

            {/* View Mode Toggle Buttons */}
            <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 mb-3 text-[11px] font-mono">
              <button
                onClick={() => setViewMode('ORIGINAL')}
                className={`py-1 rounded font-semibold transition-all cursor-pointer ${
                  viewMode === 'ORIGINAL'
                    ? 'bg-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Original
              </button>
              <button
                onClick={() => setViewMode('ELA')}
                className={`py-1 rounded font-semibold transition-all cursor-pointer ${
                  viewMode === 'ELA'
                    ? 'bg-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                ELA Heatmap
              </button>
              <button
                onClick={() => setViewMode('PHOTO')}
                className={`py-1 rounded font-semibold transition-all cursor-pointer ${
                  viewMode === 'PHOTO'
                    ? 'bg-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Photo Zoom
              </button>
            </div>

            {/* Main Interactive Image Frame */}
            <div className="relative rounded-lg overflow-hidden border border-slate-750 bg-slate-950/90 aspect-[4/3] flex items-center justify-center p-2">
              <img
                src={
                  viewMode === 'ELA'
                    ? elaImageUrl
                    : viewMode === 'PHOTO'
                    ? docPhotoUrl
                    : docImageUrl
                }
                alt="Document Forensic Inspection"
                className="max-h-full max-w-full object-contain rounded"
              />

              {viewMode === 'ELA' && (
                <div className="absolute bottom-2 right-2 bg-slate-950/90 px-2 py-1 rounded text-[10px] font-mono text-amber-300 border border-amber-800/60">
                  JPEG Q90 Compression Error Map
                </div>
              )}
            </div>

            {/* Forensics Anomaly Indicator Box */}
            <div className="mt-4 p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2 text-xs font-mono">
              <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wide border-b border-slate-800 pb-1">
                Possible Tampering Detected:
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Error Level (ELA):</span>
                <span
                  className={`font-bold ${
                    (tamper?.ela_anomaly_score || 0) >= 0.35
                      ? 'text-rose-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {Math.round((tamper?.ela_anomaly_score || 0) * 100)}% Discrepancy
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Photo Perimeter Edge:</span>
                <span
                  className={`font-bold ${
                    (tamper?.photo_splicing_score || 0) >= 0.45
                      ? 'text-rose-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {Math.round((tamper?.photo_splicing_score || 0) * 100)}% Gradient
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Noise Variance:</span>
                <span className="text-slate-200">
                  {Math.round((tamper?.noise_variance_score || 0) * 100)}% Residual
                </span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-slate-800">
                <span className="text-slate-400">Metadata Tamper Flag:</span>
                <span
                  className={
                    tamper?.metadata_manipulation_flag
                      ? 'text-rose-400 font-bold'
                      : 'text-emerald-400'
                  }
                >
                  {tamper?.metadata_manipulation_flag ? 'FLAGGED (Editor Metadata)' : 'CLEAR'}
                </span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-slate-800">
                <span className="text-slate-400">AI Forgery Detection (ViT):</span>
                <span
                  className={`font-bold ${
                    forge?.verdict === 'FORGED' ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {forge?.verdict === 'FORGED'
                    ? `FORGED (${Math.round((forge?.forge_probability || 0) * 100)}%)`
                    : forge?.model_name
                    ? `AUTHENTIC (${Math.round((forge?.forge_probability || 0) * 100)}%)`
                    : 'MODEL UNAVAILABLE'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Stamp / Seal Forgery Risk:</span>
                <span
                  className={`font-bold ${
                    stamp?.suspicious ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {stamp?.suspicious
                    ? `SUSPICIOUS (${Math.round((stamp?.forgery_risk || 0) * 100)}%)`
                    : `${Math.round((stamp?.forgery_risk || 0) * 100)}% (${stamp?.stamp_count ?? 0} region${(stamp?.stamp_count ?? 0) === 1 ? '' : 's'})`}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* COLUMN 2: Extracted Fields & Checkpoint Matrix (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Biographical Data Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-indigo-400" />
              <span>Biographical Data Extraction (VIZ vs MRZ)</span>
            </h2>

            <div className="space-y-2 text-xs">
              {[
                { label: 'Document Number', val: ext?.document_number, mrzVal: mrz?.line2?.slice(0, 9).replace(/</g, '') },
                { label: 'Full Name', val: ext?.full_name, mrzVal: mrz?.line1?.slice(5).replace(/</g, ' ').trim() },
                { label: 'Nationality', val: ext?.nationality, mrzVal: mrz?.line2?.slice(10, 13) },
                { label: 'Date of Birth', val: ext?.date_of_birth, mrzVal: mrz?.line2?.slice(13, 19) },
                { label: 'Gender', val: ext?.gender, mrzVal: mrz?.line2?.slice(20, 21) },
                { label: 'Date of Expiry', val: ext?.expiry_date, mrzVal: mrz?.line2?.slice(21, 27) },
              ].map((row, idx) => {
                const isMatch = !row.mrzVal || (row.val && row.val.toUpperCase().includes(row.mrzVal.toUpperCase()));
                return (
                  <div
                    key={idx}
                    className="p-2 rounded bg-slate-950 border border-slate-800/80 flex items-center justify-between"
                  >
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                        {row.label}
                      </span>
                      <span className="font-mono font-medium text-slate-200">
                        {row.val || '—'}
                      </span>
                    </div>
                    <div className="text-right font-mono text-[11px]">
                      <span
                        className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] ${
                          isMatch
                            ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-900'
                            : 'bg-amber-950/60 text-amber-400 border border-amber-900'
                        }`}
                      >
                        {isMatch ? <Check className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                        <span>{isMatch ? 'MATCH' : 'REVIEW'}</span>
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ICAO 9303 MRZ Checksum Terminal */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-indigo-400" />
                <span>ICAO Doc 9303 Checksum Engine</span>
              </h2>
              <span
                className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                  mrz?.all_checksums_valid
                    ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                    : 'bg-rose-950 text-rose-400 border-rose-800 animate-pulse'
                }`}
              >
                {mrz?.all_checksums_valid ? 'ALL CHECKSUMS VALID' : 'CHECKSUM FAILURE'}
              </span>
            </div>

            {/* Raw MRZ Box */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs text-indigo-300 space-y-1 tracking-wider overflow-x-auto">
              <div>{mrz?.line1 || 'P<INDRANKA<<ABHISHEK<<<<<<<<<<<<<<<<<<<<<<<'}</div>
              <div>{mrz?.line2 || 'P1284920<6IND8806144M2801098<<<<<<<<<<<<<<8'}</div>
              {mrz?.line3 && <div>{mrz.line3}</div>}
            </div>

            {/* 4 Checksum Results */}
            <div className="grid grid-cols-2 gap-2 mt-3 text-[11px] font-mono">
              <div
                className={`p-2 rounded border flex items-center justify-between ${
                  mrz?.valid_doc_number_checksum
                    ? 'bg-emerald-950/40 text-emerald-300 border-emerald-900'
                    : 'bg-rose-950/40 text-rose-300 border-rose-900'
                }`}
              >
                <span>Doc No Check Digit:</span>
                <span className="font-bold">{mrz?.valid_doc_number_checksum ? 'PASS' : 'FAIL'}</span>
              </div>

              <div
                className={`p-2 rounded border flex items-center justify-between ${
                  mrz?.valid_dob_checksum
                    ? 'bg-emerald-950/40 text-emerald-300 border-emerald-900'
                    : 'bg-rose-950/40 text-rose-300 border-rose-900'
                }`}
              >
                <span>DOB Check Digit:</span>
                <span className="font-bold">{mrz?.valid_dob_checksum ? 'PASS' : 'FAIL'}</span>
              </div>

              <div
                className={`p-2 rounded border flex items-center justify-between ${
                  mrz?.valid_expiry_checksum
                    ? 'bg-emerald-950/40 text-emerald-300 border-emerald-900'
                    : 'bg-rose-950/40 text-rose-300 border-rose-900'
                }`}
              >
                <span>Expiry Check Digit:</span>
                <span className="font-bold">{mrz?.valid_expiry_checksum ? 'PASS' : 'FAIL'}</span>
              </div>

              <div
                className={`p-2 rounded border flex items-center justify-between ${
                  mrz?.valid_composite_checksum
                    ? 'bg-emerald-950/40 text-emerald-300 border-emerald-900'
                    : 'bg-rose-950/40 text-rose-300 border-rose-900'
                }`}
              >
                <span>Composite Check:</span>
                <span className="font-bold">{mrz?.valid_composite_checksum ? 'PASS' : 'FAIL'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* COLUMN 3: Biometrics, Registries & Decision Actions (3 cols) */}
        <div className="lg:col-span-3 space-y-4">
          {/* Explainable AI Explanation Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-amber-400" />
                <span>Explanation (Explainable AI)</span>
              </h2>
              <span className="text-[10px] font-mono text-slate-500">
                Why this verdict
              </span>
            </div>

            <div
              className={`p-2.5 rounded-lg border text-xs font-bold flex items-center gap-2 mb-2 ${
                explanation.tone === 'good'
                  ? 'bg-emerald-950/40 border-emerald-900 text-emerald-300'
                  : explanation.tone === 'bad'
                  ? 'bg-rose-950/40 border-rose-900 text-rose-300'
                  : 'bg-amber-950/40 border-amber-900 text-amber-300'
              }`}
            >
              <span className="text-sm">{explanation.tone === 'good' ? '✓' : explanation.tone === 'bad' ? '⚠️' : 'ⓘ'}</span>
              <span>
                {explanation.verdict} — Score {risk?.risk_score || 0}/100
              </span>
            </div>

            <ul className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
              {explanation.points.length === 0 ? (
                <li className="p-2 text-xs text-slate-400 bg-slate-950/40 rounded border border-slate-800">
                  No verification signals were generated for this case.
                </li>
              ) : (
                explanation.points.map((p, idx) => (
                  <li
                    key={idx}
                    className="p-2 rounded bg-slate-950 border border-slate-800 text-[11px] flex items-start gap-2"
                  >
                    <span
                      className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0 ${
                        p.tone === 'good'
                          ? 'bg-emerald-400'
                          : p.tone === 'bad'
                          ? 'bg-rose-400'
                          : 'bg-amber-400'
                      }`}
                    />
                    <span
                      className={`leading-snug ${
                        p.tone === 'bad' ? 'text-rose-200' : p.tone === 'good' ? 'text-slate-200' : 'text-slate-300'
                      }`}
                    >
                      {p.text}
                    </span>
                  </li>
                ))
              )}
            </ul>
          </div>

          {/* Biometric Face Verification */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Camera className="w-4 h-4 text-indigo-400" />
              <span>Face Match Confidence (AI Biometrics)</span>
            </h2>

            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="text-center">
                <span className="text-[10px] font-mono text-slate-400 block mb-1">Doc Portrait</span>
                <div className="w-full h-24 rounded bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center p-1">
                  <img src={docPhotoUrl} alt="Doc Face" className="max-h-full max-w-full object-contain rounded" />
                </div>
              </div>

              <div className="text-center">
                <span className="text-[10px] font-mono text-slate-400 block mb-1">Live Capture</span>
                <div className="w-full h-24 rounded bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center p-1">
                  {livePhotoUrl ? (
                    <img src={livePhotoUrl} alt="Live Face" className="max-h-full max-w-full object-contain rounded" />
                  ) : (
                    <span className="text-[10px] text-slate-500 font-mono">No Live Photo</span>
                  )}
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono">
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">Confidence Score:</span>
                <span
                  className={`font-bold ${
                    face?.match_status === 'MATCH'
                      ? 'text-emerald-400'
                      : face?.match_status === 'MISMATCH'
                      ? 'text-rose-400'
                      : 'text-amber-400'
                  }`}
                >
                  {face?.similarity_score ?? 0}% ({face?.match_status || 'INCONCLUSIVE'})
                </span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className={`h-full ${
                    face?.match_status === 'MATCH'
                      ? 'bg-emerald-500'
                      : face?.match_status === 'MISMATCH'
                      ? 'bg-rose-500'
                      : 'bg-amber-500'
                  }`}
                  style={{ width: `${face?.similarity_score ?? 0}%` }}
                />
              </div>
            </div>
          </div>

          {/* Registry Checks */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-indigo-400" />
              <span>REGISTRY CHECK</span>
            </h2>

            <div
              className={`p-2.5 rounded-lg border text-xs font-mono ${
                reg?.check_status === 'CLEAR'
                  ? 'bg-emerald-950/40 border-emerald-900 text-emerald-300'
                  : 'bg-rose-950/60 border-rose-800 text-rose-300'
              }`}
            >
              <div className="flex items-center justify-between font-bold">
                <span>STATUS:</span>
                <span>{reg?.check_status || 'CLEAR'}</span>
              </div>
              {reg?.matched_registry && (
                <div className="text-[11px] mt-1 pt-1 border-t border-rose-900/60">
                  <span className="font-semibold block">{reg.matched_registry}</span>
                </div>
              )}
            </div>
          </div>

          {/* Explainable Risk Factors List */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Risk Assessment Factors</span>
              <span className="text-[10px] font-mono text-slate-400">
                Score: {risk?.risk_score}/100
              </span>
            </h2>

            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {(risk?.contributing_factors_json || []).length === 0 ? (
                <div className="p-2 text-center text-xs text-emerald-400 bg-emerald-950/30 rounded border border-emerald-900/50">
                  ✓ Clean Document (No risk flags triggered)
                </div>
              ) : (
                risk?.contributing_factors_json?.map((f, idx) => (
                  <div
                    key={idx}
                    className="p-2 rounded bg-slate-950 border border-slate-800 text-[11px]"
                  >
                    <div className="flex justify-between items-start">
                      <span className="font-bold text-rose-400">{f.title}</span>
                      <span className="font-mono text-slate-400">+{f.points}</span>
                    </div>
                    <p className="text-slate-400 text-[10px] mt-0.5 leading-tight">
                      {f.description}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Official Officer Determination Action Bar */}
          <div className="bg-slate-900 border border-indigo-900/60 rounded-xl p-4 shadow-lg space-y-3">
            <h2 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
              <FileCheck className="w-4 h-4 text-indigo-400" />
              <span>Officer Decision & Sign-off (Decision Support)</span>
            </h2>

            <div>
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Mandatory Officer Notes:
              </label>
              <textarea
                value={officerNotes}
                onChange={(e) => setOfficerNotes(e.target.value)}
                placeholder="Enter justification, secondary inspection referral notes, or clearance remarks..."
                rows={2}
                className="w-full p-2 text-xs bg-slate-950 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => handleDecision('CLEARED')}
                disabled={submittingDecision}
                className="px-2.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition-all shadow cursor-pointer"
              >
                Clear Document
              </button>

              <button
                type="button"
                onClick={() => handleDecision('REFER_SECONDARY')}
                disabled={submittingDecision}
                className="px-2.5 py-2 rounded-lg bg-amber-700 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow cursor-pointer"
              >
                Refer Secondary
              </button>

              <button
                type="button"
                onClick={() => handleDecision('REJECTED')}
                disabled={submittingDecision}
                className="px-2.5 py-2 rounded-lg bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold transition-all shadow cursor-pointer"
              >
                Reject Entry
              </button>

              <button
                type="button"
                onClick={() => handleDecision('DETAINED')}
                disabled={submittingDecision}
                className="px-2.5 py-2 rounded-lg bg-red-900 hover:bg-red-800 text-white text-xs font-bold transition-all shadow cursor-pointer"
              >
                Detain Subject
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
