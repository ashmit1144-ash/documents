# SI(H) Prototype Presentation Script — DocVerify AI

**Round:** SIH 2026 Concept / Prototype Evaluation
**Problem Statement:** 26188 — AI-Based Fake Identity & Document Screening
**Solution:** DocVerify AI (MHA / SSB Police II Concept)

---

## 1. OPENING (30 sec) — *Screen: Login page*

> "Good morning/afternoon, respected judges. I'm [name], and this is our solution for **Problem Statement 26188: AI-Based Fake Identity and Document Screening** for the Ministry of Home Affairs and SSB Police II.
>
> **The problem is simple:** a forged document is not caught at the gate with the naked eye. By the time a fake passport, visa, or ID reaches a manual examiner, a person has already crossed a border or entered a facility — and manual checks take 5–10 minutes per traveller, at a handful of entry points.
>
> Our answer — **DocVerify AI** — is a single platform that does what a forensic lab does, automatically, in under a minute, with an explanation an officer can actually trust."

---

## 2. THE DEMO — *Screen: Login page*
> "Let me show you. I'll start the demo in real time."

- **Click LOGIN →** (enter `officer` / `officer123`, or click the **Officer** quick-login button)
> "Every officer gets a role-based login — Officer, Supervisor, Admin — with an audit trail for every action. Nothing here is unaccounted."

---

## 3. DASHBOARD (30 sec) — *Screen: Dashboard*
> "This is the command dashboard — today's screenings, risk distribution, and live watchlist alerts. Two buttons matter for this demo: **Start Screening**."

- Click **Start Screening**.

---

## 4. SCREENING (1 min) — *Screen: New Screening*
> "We can upload a live document — passport, visa, Aadhaar, driving licence, or permit — or pick a preloaded scenario."

- **Option A (FAKE doc):** choose from dropdown → *"Spliced Photo / ELA Discrepancy (US Passport)"* → click **Execute Screening**.
- **Option B (REAL doc):** drag in the genuine licence photo file.

> *(If using fake first):* "Notice it picks the exact document type and flags it as a simulated scenario. Let's execute."

---

## 5. WATCH THE PIPELINE RUN (2.5 min) — *Screen: 6-stage flow*
> "Watch the screen — this is the full forensic pipeline running live, not a video:
>
> 1. **OCR Extraction** — dual-engine text + MRZ reading;
> 2. **ICAO 9303 validation** — the mathematical 7-3-1 check digits;
> 3. **Tampering forensics** — Error Level Analysis, photo-splicing detection, metadata / EXIF editing traces;
> 4. **Face biometrics** — 512-dimensional face comparison;
> 5. **Registry check** — Interpol SLTD and Red Notice matching;
> 6. **Risk engine** — scores from 0–100 with a decision: Clear / Refer / Reject / Detain."

---

## 6. EXPLAINABLE RESULT (2 min) — *Screen: Case Inspector, RIGHT side*
> "Now the most important screen. Judges, every AI decision must justify itself — so every verdict has an **Explanation** panel.
>
> **For the forged sample:** see the red banner — *LIKELY FORGED / HIGH RISK* — and above it, the system tells the officer *why*: the photo perimeter shows discontinuity (splicing), the deep-learning forgery model flags it with X% confidence, and these factors add to the score.
>
> **For the genuine licence** *(if shown):* the same system says *AUTHENTIC — No Forgery Indication*, and each green line explains *why it is real* — MRZ checks, forensics are clean, registry is clear.
>
> This matters: officers don't just get a score, they get a **reason** — so a decision can be defended, and so the AI builds trust instead of being a black box."

- Scroll to show: MRZ panel, forensics, face confidence bar, **Download PDF Dossier**.
> "And with one click, a watermarked PDF dossier is generated for the case file — the officer can sign off, refer to secondary inspection, reject, or detain, right here."

---

## 7. VERIFIED ACCURACY STORY (45 sec) — *The key moment*
> "Let me be honest about how we built this answer. When we tested a **100% genuine Indian driving licence**, our first version scored it **100 — HIGH RISK — forged**.
>
> The root cause: the system was *fabricating an MRZ string* when the OCR found no machine-readable zone — and licences **don't have one**.
>
> We fixed the pipeline to only trust real OCR signals — a genuine document now scores **0.0 — LOW RISK**, and a spliced forgery still gets flagged. That **false-positive fix** is the difference between a demo and a deployable system: it can pass a genuine traveller *and* catch a forged one. Our full backend test-suite passes 21/21."

---

## 8. TECH STACK (30 sec)
> "Under the hood, nothing is superficial:
> - **ML:** PyTorch + Transformers, a fine-tuned document-forgery model (Zodumair ViT), running on accelerated hardware;
> - **Forensics:** ELA, splicing, EXIF/metadata, stamp/seal ink analysis;
> - **Backend:** FastAPI microservice architecture; **Frontend:** React with a full officer workflow;
> - **Security:** role-based auth, token-protected APIs, SHA-256 document logging, immutable audit log, SQLite-backed evidence database."

---

## 9. SCALABILITY & CLOSING (45 sec)
> "This is not one gate. The same API can serve **airports, railway stations, and state borders simultaneously** — batch-queue thousands of travellers, or re-query existing records from a watchlist as new hits arrive.
>
> **Respected judges, to summarise in one line: DocVerify AI is not a score — it's a forensic laboratory in a browser, with an explainable reason for every decision an officer makes.**
>
> We are ready for questions — and happy to run any scenario you'd like to test live."

---

## Back-up answers for likely judge questions

| Question | Answer |
|---|---|
| "How is this different from existing OCR tools?" | OCR only reads text; we do 6 forensic layers + a trained forgery CNN + explainable risk. Reading is 1 of 6 stages. |
| "Explainable AI — how do you generate explanations?" | Each risk factor carries a plain-language description tied to a real measured signal (check digit, ELA %, model probability), rendered in the Explanation panel. |
| "What about privacy?" | Documents are processed only for the screening, hashed (SHA-256) and stored in an internal evidence DB with role-based access and an audit trail — no third-party processing. |
| "Offline?" | The model runs locally on our stack (offline HF model snapshots) — it can run on police-intranet with no internet dependency. |
| "What happens on a false negative?" | Confidence thresholds and manual-review gates catch borderline cases; every decision is officer-signed and recorded, so the loop is human-audited. |