"""Shared pretrained-model loaders (lazy singletons) + ELA helpers.

Bridges proven implementations from the SIH reference research fork
into the DocVerify screening backend. All models are PRETRAINED publicly
hosted models (gated=False, no token needed):

  * zodumair/document-forgery-detector   -> ViT-B/16 document forge classifier
  * PaddleOCR PP-OCRv6                    -> document field OCR
  * facenet-pytorch InceptionResnetV1     -> 512-D face embeddings (VGGFace2)

When AI_BACKEND is "simulated" (tests / offline demo) every loader returns None
and the per-service callers fall back to deterministic heuristics/demo values.
"""

from __future__ import annotations

import io
import os
import threading

import numpy as np
from PIL import Image, ImageChops, ImageEnhance

from backend.app.core.config import settings

_real_backend = None


def is_real_ai() -> bool:
    """True when real pretrained models should be attempted at runtime."""
    mode = (settings.AI_BACKEND or "auto").lower()
    return mode in ("auto", "real")


_lock = threading.Lock()
_cache: dict = {}

try:
    import torch as _torch
    DEVICE = (
        "cpu"
        if os.environ.get("FORCE_CPU")
        else "cuda" if _torch.cuda.is_available() else "cpu"
    )
except Exception:
    # torch not installed -> simulated/deterministic mode
    DEVICE = "cpu"


def elt_image(pil_img: Image.Image, quality: int = 90, scale: int = 15) -> Image.Image:
    """Error Level Analysis residual. Re-encode at `quality`, diff with original."""
    pil_img = pil_img.convert("RGB")
    buf = io.BytesIO()
    pil_img.save(buf, "JPEG", quality=quality)
    buf.seek(0)
    diff = ImageChops.difference(pil_img, Image.open(buf).convert("RGB"))
    return ImageEnhance.Brightness(diff).enhance(scale)


def ela_blend(pil_img: Image.Image, alpha: float = 0.3) -> Image.Image:
    """Original blended with its ELA residual (matches zodumair prep)."""
    orig = pil_img.convert("RGB")
    ela = elt_image(orig)
    return Image.blend(orig, ela, alpha)


def ela_residual_stats(pil_img: Image.Image, quality: int = 90):
    """Numerical ELA statistics over a region (mean/std of amplified residual)."""
    arr = np.asarray(elt_image(pil_img, quality=quality).convert("L"), dtype=np.float32)
    return {
        "ela_mean": float(arr.mean()),
        "ela_std": float(arr.std()),
        "ela_p95": float(np.percentile(arr, 95)),
    }


def open_rgb(path_or_img) -> Image.Image:
    if isinstance(path_or_img, Image.Image):
        return path_or_img.convert("RGB")
    return Image.open(path_or_img).convert("RGB")


def _local_hf_snapshot(repo_id: str):
    """Return the local huggingface hub snapshot path for a repo, if present."""
    cache_root = os.environ.get(
        "HF_HOME",
        os.path.join(os.path.expanduser("~"), ".cache", "huggingface"),
    )
    folder = os.path.join(cache_root, "hub", "models--" + repo_id.replace("/", "--"))
    if not os.path.isdir(folder):
        return None
    snap_dir = os.path.join(folder, "snapshots")
    if not os.path.isdir(snap_dir):
        return None
    snaps = sorted(os.listdir(snap_dir))
    if not snaps:
        return None
    candidate = os.path.join(snap_dir, snaps[0])
    return candidate if os.path.isdir(candidate) else None


def get_forge_vit():
    """Load zodumair/document-forgery-detector (ViT-B/16, transformers).

    The remote repo is now gated (401), so if the model is already in the local
    HF hub cache we load straight from disk; otherwise fall back to the repo id.
    """
    if not is_real_ai():
        return None
    try:
        from transformers import AutoImageProcessor, AutoModelForImageClassification
    except Exception:
        return None
    with _lock:
        if "forge_vit" not in _cache:
            ckpt = _local_hf_snapshot("zodumair/document-forgery-detector") or \
                "zodumair/document-forgery-detector"
            model = AutoModelForImageClassification.from_pretrained(ckpt)
            proc = AutoImageProcessor.from_pretrained(ckpt)
            if DEVICE == "cuda":
                model = model.to("cuda")
            model.eval()
            _cache["forge_vit"] = (model, proc)
    return _cache["forge_vit"]


def get_face_pipeline():
    """facenet-pytorch MTCNN detector + InceptionResnetV1 (VGGFace2) embedder."""
    if not is_real_ai():
        return None
    try:
        from facenet_pytorch import MTCNN, InceptionResnetV1
    except Exception:
        return None
    with _lock:
        if "face" not in _cache:
            mtcnn = MTCNN(keep_all=False, device=DEVICE, min_face_size=12)
            res = InceptionResnetV1(pretrained="vggface2").eval()
            if DEVICE == "cuda":
                res = res.to("cuda")
            _cache["face"] = (mtcnn, res)
    return _cache["face"]


def get_ocr():
    """PaddleOCR PP-OCRv6 (paddlex) english pipeline, with paddle 3.x PIR workaround."""
    if not is_real_ai():
        return None
    try:
        os.environ.setdefault("FLAGS_enable_pir_api", "0")
        import paddle

        paddle.set_flags({"FLAGS_enable_pir_api": 0})
    except Exception:
        pass
    try:
        from paddleocr import PaddleOCR
    except Exception:
        return None
    with _lock:
        if "ocr" not in _cache:
            _cache["ocr"] = PaddleOCR(
                use_doc_orientation_classify=False,
                use_doc_unwarping=False,
                use_textline_orientation=False,
                lang="en",
                enable_mkldnn=False,
            )
    return _cache["ocr"]
