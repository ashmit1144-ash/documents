import os
import numpy as np
from PIL import Image, ImageOps, ImageFilter
from pathlib import Path
from typing import Dict, Any, Tuple, Optional
from backend.app.core.config import settings
from backend.app.services.ml_backend import get_face_pipeline, DEVICE, is_real_ai

class FaceService:
    @staticmethod
    def _face_model_available() -> bool:
        """True when the real facenet (MTCNN + InceptionResNet) pipeline is usable."""
        return get_face_pipeline() is not None

    @staticmethod
    def detect_and_crop_face(image_path: str, save_path: Path) -> Tuple[bool, Optional[str], float]:
        """
        Detects face, evaluates image quality/sharpness, crops and saves portrait.
        Uses MTCNN (real mode) or skin-tone/edge heuristics with ICAO MRTD portrait
        coordinates. Returns: (detected: bool, crop_relative_path: str, quality_score: float)
        """
        try:
            im = Image.open(image_path).convert('RGB')
            w, h = im.size

            # Sharpness calculation using edge filter
            edges = im.convert('L').filter(ImageFilter.FIND_EDGES)
            edge_arr = np.array(edges, dtype=np.float32)
            sharpness_var = float(np.var(edge_arr))
            quality_score = min(1.0, float(sharpness_var / 250.0))

            portrait_crop = None

            # 1. Prefer a real MTCNN face box when available (best crop for facenet)
            pipeline = get_face_pipeline()
            if pipeline is not None:
                try:
                    mtcnn = pipeline[0]
                    boxes, _conf = mtcnn.detect(im)
                    if boxes is not None and len(boxes) > 0:
                        best = sorted(boxes, key=lambda b: (b[2] - b[0]) * (b[3] - b[1]))[-1]
                        x0, y0, x1, y1 = (int(max(0, v)) for v in best)
                        # Expand box by 30% margin, clamp to image bounds
                        bw, bh = x1 - x0, y1 - y0
                        m = 0.3
                        nx0 = max(0, int(x0 - bw * m))
                        ny0 = max(0, int(y0 - bh * m))
                        nx1 = min(w, int(x1 + bw * m))
                        ny1 = min(h, int(y1 + bh * m))
                        portrait_crop = im.crop((nx0, ny0, nx1, ny1))
                except Exception:
                    portrait_crop = None

            # 2. Standalone cropped portrait (aspect ~ square, moderate height)
            if portrait_crop is None and 0.7 <= (w / h) <= 1.3 and h <= 500:
                portrait_crop = im

            # 3. ICAO document page crop: passport portrait zone (left 5-40%, top 15-72%)
            if portrait_crop is None:
                crop_x1 = int(w * 0.03)
                crop_y1 = int(h * 0.15)
                crop_x2 = int(w * 0.40)
                crop_y2 = int(h * 0.72)
                portrait_crop = im.crop((crop_x1, crop_y1, crop_x2, crop_y2))

            # 4. Zero-confidence fallback: whole image
            if portrait_crop is None or portrait_crop.size[0] < 16 or portrait_crop.size[1] < 16:
                portrait_crop = im

            save_path.parent.mkdir(parents=True, exist_ok=True)
            portrait_crop.save(save_path, format='JPEG', quality=92)

            return True, f"/storage/portraits/{save_path.name}", float(round(quality_score, 2))

        except Exception:
            return False, None, 0.0

    @staticmethod
    def _real_embed_face(image_path: str) -> Optional[np.ndarray]:
        """Detect + embed the largest face via MTCNN + InceptionResnetV1 (VGGFace2)."""
        pipeline = get_face_pipeline()
        if pipeline is None:
            return None
        from facenet_pytorch import MTCNN, InceptionResnetV1
        mtcnn, resnet = pipeline
        try:
            img = Image.open(image_path).convert('RGB')
            boxes, conf = mtcnn.detect(img)
            if boxes is None or len(boxes) == 0:
                return None
            aligned, prob = mtcnn(img, return_prob=True)
            if aligned is None:
                return None
            emb = resnet(aligned.unsqueeze(0).to(DEVICE))
            v = emb[0].detach().cpu().numpy()
            n = np.linalg.norm(v)
            return (v / (n + 1e-9)).astype(np.float32)
        except Exception:
            return None

    @staticmethod
    def extract_face_descriptor_with_flag(image_path: str) -> Tuple[Optional[np.ndarray], bool]:
        """Embed a face; returns (embedding, used_real_model).

        When the real facenet embedder actually produced the vector the second
        element is True. If the model is unavailable OR no face was detectable
        (so the heuristic descriptor was used instead) it is False.
        """
        if is_real_ai():
            real_emb = FaceService._real_embed_face(image_path)
            if real_emb is not None:
                return real_emb, True
        desc = FaceService._heuristic_descriptor(image_path)
        return desc, False

    @staticmethod
    def extract_face_descriptor(image_path: str) -> Optional[np.ndarray]:
        """
        Extracts standardized 512-dimensional normalized facial feature vector.

        With AI_BACKEND=auto/real this uses the facenet-pytorch InceptionResnetV1
        (VGGFace2) pretrained embedder. Falls back to a multi-scale normalized 2D
        frequency-band + gradient-histogram descriptor (512-D) when the real model
        is unavailable (simulated mode / offline demo).
        """
        emb, _ = FaceService.extract_face_descriptor_with_flag(image_path)
        return emb

    @staticmethod
    def _heuristic_descriptor(image_path: str) -> Optional[np.ndarray]:
        try:
            im = Image.open(image_path).convert('L')
            # Standardize face size to 128x128
            resized = im.resize((128, 128))
            
            # Histogram Equalization
            equalized = ImageOps.equalize(resized)
            arr = np.array(equalized, dtype=np.float32) / 255.0
            
            # 1. 2D Frequency features via 2D FFT / DCT approximation (256 dims)
            fft2 = np.fft.fft2(arr)
            fft_mag = np.abs(np.fft.fftshift(fft2))
            # Sample low-to-mid frequency grid (16x16 = 256)
            center = 64
            freq_features = fft_mag[center-8:center+8, center-8:center+8].flatten()
            
            # 2. Spatial Directional Gradients (256 dims)
            # Sobel-like spatial diffs
            gx = np.zeros_like(arr)
            gy = np.zeros_like(arr)
            gx[:, 1:-1] = arr[:, 2:] - arr[:, :-2]
            gy[1:-1, :] = arr[2:, :] - arr[:-2, :]
            
            mag = np.sqrt(gx**2 + gy**2)
            angle = (np.arctan2(gy, gx + 1e-6) * (180.0 / np.pi)) % 360.0
            
            # Compute 16-bin histograms across 4x4 spatial blocks (16 * 16 = 256)
            spatial_features = []
            cell_size = 32
            for cy in range(0, 128, cell_size):
                for cx in range(0, 128, cell_size):
                    cell_mag = mag[cy:cy+cell_size, cx:cx+cell_size]
                    cell_ang = angle[cy:cy+cell_size, cx:cx+cell_size]
                    hist, _ = np.histogram(cell_ang, bins=16, range=(0, 360), weights=cell_mag)
                    spatial_features.extend(hist)
            
            # Combine 256 frequency + 256 gradient -> 512-D embedding
            combined = np.concatenate([
                np.array(freq_features, dtype=np.float32),
                np.array(spatial_features, dtype=np.float32)
            ])
            
            # L2 Normalization
            norm = np.linalg.norm(combined)
            if norm > 0:
                normalized_embedding = combined / norm
            else:
                normalized_embedding = combined
                
            return normalized_embedding
            
        except Exception:
            return None

    @staticmethod
    def verify_faces(
        document_image_path: str,
        live_image_path: Optional[str],
        document_id: str
    ) -> Dict[str, Any]:
        """
        Extracts document face, processes live portrait, and calculates Cosine similarity match.
        """
        doc_crop_filename = f"doc_{document_id}.jpg"
        doc_crop_path = settings.PORTRAITS_DIR / doc_crop_filename
        
        doc_detected, doc_rel_path, doc_quality = FaceService.detect_and_crop_face(
            document_image_path,
            doc_crop_path
        )
        
        if not live_image_path or not os.path.exists(live_image_path):
            return {
                "doc_face_detected": doc_detected,
                "doc_face_crop_path": doc_rel_path,
                "live_face_detected": False,
                "live_face_path": None,
                "similarity_score": 0.0,
                "match_status": "NO_LIVE_CAPTURE",
                "confidence": 0.0
            }
            
        live_crop_filename = f"live_{document_id}.jpg"
        live_crop_path = settings.PORTRAITS_DIR / live_crop_filename
        
        live_detected, live_rel_path, live_quality = FaceService.detect_and_crop_face(
            live_image_path,
            live_crop_path
        )
        
        if not doc_detected or not live_detected:
            status = "LOW_QUALITY" if (doc_quality < 0.2 or live_quality < 0.2) else "FACE_NOT_DETECTED"
            return {
                "doc_face_detected": doc_detected,
                "doc_face_crop_path": doc_rel_path,
                "live_face_detected": live_detected,
                "live_face_path": live_rel_path,
                "similarity_score": 0.0,
                "match_status": status,
                "confidence": 0.3
            }

        desc_doc, _real_doc = FaceService.extract_face_descriptor_with_flag(str(doc_crop_path))
        desc_live, _real_live = FaceService.extract_face_descriptor_with_flag(str(live_crop_path))
        _REAL_BOTH = bool(_real_doc and _real_live)

        if desc_doc is None or desc_live is None:
            return {
                "doc_face_detected": True,
                "doc_face_crop_path": doc_rel_path,
                "live_face_detected": True,
                "live_face_path": live_rel_path,
                "similarity_score": 0.0,
                "match_status": "INCONCLUSIVE",
                "confidence": 0.4,
                "engine_mode": "real-facenet" if _REAL_BOTH else "heuristic-fallback",
                "note": None if _REAL_BOTH else "Face verification ran in fallback mode; automatic identity-match confirmation disabled."
            }
            
        # Cosine Similarity between normalized vectors
        cosine_sim = float(np.dot(desc_doc, desc_live))
        
        # Calibration curve for standard security display (0% - 100%)
        normalized_score = max(0.0, min(100.0, (cosine_sim - 0.20) / 0.70 * 100.0))
        similarity_pct = float(round(normalized_score, 1))
        
        # Real-Model Awareness: a "MATCH" verdict is only trustworthy when the
        # real facenet embedder actually produced both face vectors. If either
        # side fell back to the composition heuristic, two different people can
        # score near 100% and an automatic MATCH would be a false positive.
        real_used = _REAL_BOTH
        
        if similarity_pct >= 70.0:
            if real_used:
                match_status = "MATCH"
                confidence = min(0.99, float(similarity_pct / 100.0))
            else:
                match_status = "INCONCLUSIVE"
                confidence = 0.55
        elif similarity_pct >= 52.0:
            match_status = "INCONCLUSIVE"
            confidence = 0.55
        else:
            match_status = "MISMATCH"
            confidence = max(0.60, 1.0 - float(similarity_pct / 100.0))
            
        return {
            "doc_face_detected": True,
            "doc_face_crop_path": doc_rel_path,
            "live_face_detected": True,
            "live_face_path": live_rel_path,
            "similarity_score": similarity_pct,
            "match_status": match_status,
            "confidence": float(round(confidence, 2)),
            "engine_mode": "real-facenet" if real_used else "heuristic-fallback",
            "note": None if real_used else "Face verification ran in fallback mode; automatic identity-match confirmation disabled."
        }
