"""Image metadata (EXIF / container) forensics.

Flags editing software, capture-vs-modify date inconsistency, GPS on a scanned
document, and screenshot / thumbnail rewrite markers. Ported from the research
fork's metadata_analysis.py and integrated into the DocVerify forensics stage.
"""

from __future__ import annotations

import io
import os
import re
from datetime import datetime
from typing import Any, Dict, Tuple

try:
    import exifread as _exifread
except Exception:
    # exifread is optional: fall back to Pillow's built-in EXIF loader.
    _exifread = None

from PIL import Image

from backend.app.core.config import settings


def _read_tags(path_or_bytes) -> Dict[str, Any]:
    data = path_or_bytes
    if isinstance(data, str):
        with open(data, "rb") as f:
            data = f.read()
    if _exifread is not None:
        tags = _exifread.process_file(io.BytesIO(data), details=False)
        return {k: str(v)[:200] for k, v in tags.items()}
    try:
        img = Image.open(io.BytesIO(data))
        exif = img.getexif()
        return {str(k): str(v)[:200] for k, v in exif.items()}
    except Exception:
        return {}


def _date_parse(s: str):
    m = re.search(r"(\d{4}):(\d{2}):(\d{2})\s+(\d{2}):(\d{2}):(\d{2})", s)
    if not m:
        return None
    try:
        return datetime(*(int(g) for g in m.groups()))
    except Exception:
        return None


def inspect_metadata(image_path: str) -> Tuple[bool, float, Dict[str, Any]]:
    """Analyze EXIF + file-level metadata for manipulation evidence.

    Returns (manipulation_flag, risk 0..1, details dict).
    """
    try:
        tags = _read_tags(image_path)
    except Exception:
        return False, 0.0, {"error": "unreadable"}

    risk = 0.0
    findings = []
    software = ""
    make_model = ""
    for k in ("Image Software", "Image Make", "Image Model"):
        if k in tags:
            software = tags.get("Image Software", software)
            make_model = tags.get("Image Make") or tags.get("Image Model") or make_model

    has_exif = len(tags) > 0

    if software:
        sw = software.lower()
        if any(s in sw for s in settings.SUSPICIOUS_SOFTWARE):
            findings.append(f"Edited with {software} (editing tool)")
            risk += 0.55 - (0.15 if any(t in sw for t in settings.SCREENSHOT_SOFTWARE) else 0.0)
        elif any(s in sw for s in ("gimp", "krita")):
            findings.append(f"Open-source editor detected: {software}")
            risk += 0.45

    dt_o = _date_parse(tags.get("EXIF DateTimeOriginal", "")) or _date_parse(tags.get("Image DateTime", ""))
    dt_d = _date_parse(tags.get("EXIF DateTimeDigitized", ""))
    if dt_o and dt_d and abs((dt_o - dt_d).total_seconds()) > 3600:
        findings.append("Original-capture and digitized timestamps differ by > 1h")
        risk += 0.3

    if any(k.startswith("GPS ") for k in tags):
        findings.append("GPS metadata present on a document scan")
        risk += 0.5

    if "EXIF UserComment" in tags and tags["EXIF UserComment"].strip():
        findings.append("User comment field populated (uncommon for official scans)")
        risk += 0.2

    thumbnail_present = any("Thumbnail" in k for k in tags)
    if thumbnail_present:
        findings.append("EXIF thumbnail present (often rewritten by editors)")

    try:
        st = os.stat(image_path)
        img = Image.open(image_path)
        w, h = img.size
        img.close()
        if dt_o and st.st_mtime and abs(dt_o.timestamp() - st.st_mtime) > 30 * 86400:
            findings.append("Capture date set long before file created (> 30 days)")
            risk += 0.25
    except Exception:
        pass

    if not has_exif and not findings:
        findings.append("No EXIF metadata (consistent with teller-sided scan/print)")

    risk = max(0.0, min(1.0, risk))
    manipulation_flag = risk >= settings.METADATA_SUSPICIOUS_THRESHOLD
    return manipulation_flag, round(risk, 4), {
        "has_exif": has_exif,
        "software": software or None,
        "camera": make_model or None,
        "thumbnail_present": thumbnail_present,
        "findings": findings,
        "metadata_risk": round(risk, 4),
        "manipulation_flag": manipulation_flag,
    }
