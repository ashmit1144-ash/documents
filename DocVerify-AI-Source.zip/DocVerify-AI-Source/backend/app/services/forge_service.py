"""Document-level forgery / tampering detection with a real pretrained model.

Uses zodumair/document-forgery-detector (ViT-B/16 fine-tuned on ELA-blended
forged documents). Input is the original blended with its ELA residual to match
the model's training prep.

When AI_BACKEND=simulated (or the model can't be loaded) it returns a neutral
pass-through result so the pipeline stays deterministic in tests/demo mode.
"""

from __future__ import annotations

from typing import Any, Dict

import numpy as np
from PIL import Image

try:
    import torch as _torch
except Exception:
    # torch optional: real ViT forgery model simply stays disabled.
    _torch = None

from backend.app.core.config import settings
from backend.app.services.ml_backend import (
    DEVICE,
    ela_blend,
    get_forge_vit,
    is_real_ai,
    open_rgb,
)

MODEL_REPO = "zodumair/document-forgery-detector"


def _vit_predict(pil_img: Image.Image) -> float:
    """ELA-blended ViT (zodumair). Returns forged probability in [0, 1]."""
    loaded = get_forge_vit()
    if loaded is None or _torch is None:
        raise RuntimeError("forge ViT unavailable")
    torch = _torch
    model, proc = loaded
    blended = ela_blend(pil_img)
    inp = proc(images=[blended], return_tensors="pt")
    inp = {k: (v.to(DEVICE) if DEVICE == "cuda" else v) for k, v in inp.items()}
    with torch.no_grad():
        logits = model(**inp).logits
    probs = torch.softmax(logits, dim=-1)[0].cpu().numpy()
    forged = float(probs[1]) if probs.shape[0] > 1 else float(probs[0])
    return forged


def analyze_document(image_path_or_img) -> Dict[str, Any]:
    """Run document-level forgery screening.

    Returns a structured result. The verdict / risk is meaningful only when a
    real model is available; otherwise a safe neutral (AUTHENTIC, risk=0) result
    is returned and `model_hit` stays False.
    """
    img = open_rgb(image_path_or_img)

    if not is_real_ai():
        return {
            "forge_probability": 0.0,
            "verdict": "AUTHENTIC",
            "risk": 0.0,
            "model_name": None,
            "model_hit": False,
            "details_json": {"engine_mode": "simulated", "note": "Real-model forge detection disabled (AI_BACKEND!=auto/real)."},
        }

    try:
        forge_prob = _vit_predict(img)
    except Exception as e:  # model load failure or inference error
        return {
            "forge_probability": 0.0,
            "verdict": "AUTHENTIC",
            "risk": 0.0,
            "model_name": MODEL_REPO,
            "model_hit": False,
            "details_json": {"engine_mode": "real", "error": str(e)[:300],
                             "note": "Forge model could not be loaded on this runtime."},
        }

    verdict = "FORGED" if forge_prob >= settings.DOC_FORGE_THRESHOLD else "AUTHENTIC"
    risk = float(np.clip((forge_prob - 0.5) * 2.0, 0.0, 1.0))
    model_hit = forge_prob >= settings.DOC_FORGE_STRONG_SIGNAL

    return {
        "forge_probability": round(forge_prob, 4),
        "verdict": verdict,
        "risk": round(risk, 4),
        "model_name": MODEL_REPO,
        "model_hit": model_hit,
        "details_json": {"engine_mode": "real", "models": {"vit_ela_blend": round(forge_prob, 4)},
                         "strong_signal": model_hit},
    }
