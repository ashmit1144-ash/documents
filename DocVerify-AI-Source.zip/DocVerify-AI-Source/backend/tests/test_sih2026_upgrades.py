"""Tests for the SIH 2026 upgrades: stamp forgery, real-model forge detection,
and metadata forensics risk factors, plus the AI_BACKEND simulated switch."""

import io
import os

import numpy as np
from PIL import Image

from backend.app.core.config import settings
from backend.app.schemas.schemas import RiskWeightSettings
from backend.app.services.risk_engine import RiskEngine
from backend.app.services.metadata_service import inspect_metadata
from backend.app.api.settings import CURRENT_RISK_WEIGHTS


def _make_png(size=(300, 200), color=(255, 255, 255)):
    img = Image.new("RGB", size, color)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf


def test_ai_backend_defaults_to_auto():
    assert hasattr(settings, "AI_BACKEND")
    assert settings.AI_BACKEND.lower() in ("auto", "real", "simulated")


def test_stamp_forgery_risk_factor_triggered():
    factors = RiskEngine.calculate_risk(
        mrz_data=None,
        validation_data=None,
        tampering_data=None,
        face_data=None,
        registry_data=None,
        stamp_data={"forgery_risk": 0.7, "suspicious": True, "stamp_count": 3},
        forge_data=None,
    )
    codes = [f["code"] for f in factors["contributing_factors_json"]]
    assert "STAMP_ANOMALY" in codes
    assert factors["requires_manual_review"] is True


def test_forge_model_risk_factor_triggered():
    factors = RiskEngine.calculate_risk(
        mrz_data=None,
        validation_data=None,
        tampering_data=None,
        face_data=None,
        registry_data=None,
        stamp_data=None,
        forge_data={
            "verdict": "FORGED",
            "forge_probability": 0.92,
            "risk": 0.84,
            "model_name": "zodumair/document-forgery-detector",
            "model_hit": True,
        },
    )
    codes = [f["code"] for f in factors["contributing_factors_json"]]
    assert "DOC_FORGE_MODEL" in codes
    assert any(f["severity"] == "CRITICAL" for f in factors["contributing_factors_json"])


def test_metadata_anomaly_risk_factor_triggered():
    factors = RiskEngine.calculate_risk(
        mrz_data=None,
        validation_data=None,
        tampering_data={"metadata_details": {"metadata_risk": 0.6}},
        face_data=None,
        registry_data=None,
        stamp_data=None,
        forge_data=None,
    )
    codes = [f["code"] for f in factors["contributing_factors_json"]]
    assert "META_ANOMALY" in codes


def test_risk_weights_include_new_fields():
    weights = CURRENT_RISK_WEIGHTS
    assert weights.doc_forge_model_weight > 0
    assert weights.stamp_anomaly_weight > 0
    assert weights.metadata_anomaly_weight > 0


def test_metadata_service_happy_path(tmp_path):
    # A plain PNG with no editing software must not flag manipulation
    p = tmp_path / "scan.png"
    img = Image.new("RGB", (400, 250), (240, 240, 240))
    img.save(p, format="PNG")
    flag, risk, details = inspect_metadata(str(p))
    assert flag is False
    assert 0.0 <= risk <= 1.0
    assert "findings" in details


def test_simulated_services_return_neutral(tmp_path):
    from backend.app.services.forge_service import analyze_document
    from backend.app.services.ml_backend import is_real_ai

    # conftest forces simulated; the forge service must return a safe neutral result
    assert is_real_ai() is False
    p = tmp_path / "doc.png"
    Image.new("RGB", (400, 250), (200, 200, 200)).save(p, format="PNG")
    res = analyze_document(str(p))
    assert res["model_hit"] is False
    assert res["verdict"] == "AUTHENTIC"
    assert res["risk"] == 0.0
