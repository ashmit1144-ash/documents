"""Test configuration.

Forces AI_BACKEND=simulated so unit/integration tests run deterministically
without downloading or loading real Hugging Face / PaddleOCR / facenet models.
The setting must be applied before the app's `Settings` singleton is instantiated.

Note: tests run against the seeded local `docverify.db` (see .env) so the
`officer` user and demo screenings are present, matching the original suite.
"""

import os

os.environ.setdefault("AI_BACKEND", "simulated")

