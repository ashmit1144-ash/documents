@echo off
title DocVerify AI - Starting Servers...
cd /d "C:\Users\JISHAN\OneDrive\Documents\Default Project\sih-reference"

set "VENV=C:\Users\JISHAN\OneDrive\Documents\Default Project\sih-identity-screening\.venv\Scripts\python.exe"
set "NODE=C:\Users\JISHAN\AppData\Local\Programs\nodejs\node-v24.19.0-win-x64"
set "ROOT=C:\Users\JISHAN\OneDrive\Documents\Default Project\sih-reference"
set "FRONT=%ROOT%\frontend"

echo Starting Backend...
start "DocVerify-Backend" "%VENV%" -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000

echo Starting Frontend...
start "DocVerify-Frontend" cmd /c "cd /d ""%FRONT%"" && ""%NODE%\node.exe"" ""%FRONT%\node_modules\vite\bin\vite.js"" --host"

echo.
echo ========================================
echo  Servers are starting...
echo  Frontend:  http://localhost:5173  (Login: officer / officer123)
echo  Backend:   http://127.0.0.1:8000
echo  (Backend takes 40-60s to become ready - model loading)
echo ========================================
echo.
echo Opening browser in 20 seconds...
timeout /t 20 /nobreak >nul
start http://localhost:5173
