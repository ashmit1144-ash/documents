"""Generate a paired real/fake document test set for the forgery detector.

Renders realistic document images (government ID, invoice, certificate) with
PIL, then creates FORGED variants using the same attack classes the model was
trained on (see zodumair model card):

  * copy-move        - duplicate a region over a text field
  * text-replace     - erase a field and re-print new text over it
  * stamp overlay    - paste a red "verification" stamp over the document
  * splice           - paste a region from another document
  * double-compress  - re-save the whole doc at lower JPEG quality

Pairs are written as:
  <out>/real/docs_<i>.jpg          (authentic)
  <out>/fake/docs_<i>.jpg          (forged variant of the same doc)

So the model can be tested with known ground truth (evaluation script compares
prediction to the real_ / fake_ folders).

Usage:
    python tools/make_fake_docs.py <out_dir> [--n 20] [--seed 42]
"""
from __future__ import annotations

import argparse
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageEnhance, ImageFont, ImageFilter

FONT_CANDIDATES = ["arial.ttf", "calibri.ttf", "tahoma.ttf", "verdana.ttf",
                   "segoeui.ttf", "times.ttf"]


def _font(size: int) -> ImageFont.ImageFont:
    import os
    for name in FONT_CANDIDATES:
        p = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", name)
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def _paper(w: int, h: int) -> Image.Image:
    img = Image.new("RGB", (w, h), (252, 251, 247))
    d = ImageDraw.Draw(img)
    # faint layout lines like a printed form
    for y in range(90, h, 32):
        d.line([(20, y), (w - 20, y)], fill=(230, 228, 220), width=1)
    return img


def _draw_id_card(d: ImageDraw.ImageDraw, w: int, h: int, f_b, f_l, f_m,
                  name: str, number: str, right: str, addr: str):
    d.rectangle([0, 0, w, h], outline=(28, 48, 92), width=6)
    d.rectangle([24, 24, w - 24, 60], fill=(28, 48, 92))
    d.text((w // 2 - 70, 32), "GOVERNMENT ID", fill=(255, 255, 255), font=f_b)
    d.text((40, 90), name, fill=(20, 20, 20), font=f_l)
    d.text((40, 150), f"ID NO: {number}", fill=(20, 20, 20), font=f_m)
    d.text((40, 200), f"D.O.B.: {right}", fill=(20, 20, 20), font=f_m)
    # photo placeholder box
    d.rectangle([w - 190, 84, w - 50, 230], outline=(28, 48, 92), width=3)
    d.text((w - 165, 140), "[PHOTO]", fill=(90, 90, 90), font=f_m)
    d.multiline_text((40, 250), addr, fill=(60, 60, 60), font=f_m,
                     spacing=6)


def _draw_invoice(d: ImageDraw.ImageDraw, w: int, h: int, f_b, f_l, f_m,
                  comp: str, inv_no: str, amt: str, date: str, items: list[str]):
    d.rectangle([0, 0, w, h], outline=(70, 70, 70), width=3)
    d.text((40, 40), "TAX INVOICE", fill=(20, 20, 20), font=f_b)
    d.text((w - 260, 46), comp, fill=(40, 40, 40), font=f_m)
    d.text((40, 120), f"Invoice No : {inv_no}", fill=(30, 30, 30), font=f_l)
    d.text((40, 175), f"Date       : {date}", fill=(30, 30, 30), font=f_l)
    y = 250
    for it in items:
        d.text((40, y), it, fill=(30, 30, 30), font=f_m)
        y += 36
    d.line([(40, y + 16), (w - 40, y + 16)], fill=(0, 0, 0), width=2)
    d.text((w - 260, y + 36), f"AMOUNT: {amt}", fill=(10, 10, 10), font=f_l)


def _draw_certificate(d, w, h, f_b, f_l, f_m, title: str, holder: str,
                      cert_no: str, date: str):
    d.rectangle([0, 0, w, h], outline=(150, 110, 40), width=8)
    d.text((w // 2 - 130, 40), "CERTIFICATE", fill=(90, 70, 30), font=f_b)
    d.text((w // 2 - 180, 140), title, fill=(20, 20, 20), font=f_l)
    d.text((w // 2 - 90, 250), holder, fill=(20, 20, 20), font=f_l)
    d.text((w // 2 - 70, 340), f"No: {cert_no}", fill=(60, 60, 60), font=f_m)
    d.text((w // 2 - 70, 390), date, fill=(60, 60, 60), font=f_m)


def render_real(doc_type: str, rng: random.Random, i: int) -> Image.Image:
    w, h = 560, 420
    img = _paper(w, h)
    d = ImageDraw.Draw(img)
    f_b = _font(34)
    f_l = _font(26)
    f_m = _font(18)
    name = f"A. CUSTOMER {i}"
    number = f"{rng.randint(1000,9999)} {rng.randint(1000,9999)}"
    number = f"{i:07d}-{rng.randint(10,99)}"
    if doc_type == "id":
        _draw_id_card(d, w, h, f_b, f_l, f_m, name, number,
                      f"{rng.randint(1,28):02d}/{rng.randint(1,12):02d}/1990",
                      f"14, STREET {i}\nDISTRICT, STATE 1100{i}")
    elif doc_type == "invoice":
        items = [f"ITEM 1 - hardware part {rng.randint(100,999)}",
                 f"ITEM 2 - service fee {rng.randint(10,99)}.00",
                 f"ITEM 3 - materials {rng.randint(50,999)}.50"]
        _draw_invoice(d, w, h, f_b, f_l, f_m, f"Company {chr(65+i%26)}",
                      f"INV-{i:04d}", f"{rng.randint(100,9999)}.00",
                      f"2025-{rng.randint(1,12):02d}-{rng.randint(1,28):02d}", items)
    else:
        _draw_certificate(d, w, h, f_b, f_l, f_m, "OF COMPLETION",
                          f"HOLDER {i}", f"CERT-{i:05d}",
                          f"{rng.randint(1,28):02d}/{rng.randint(1,12):02d}/2024")
    # subtle noise / JPEG artifact so it looks scanned
    img = img.filter(ImageFilter.GaussianBlur(rng.uniform(0.2, 0.5)))
    # resample to look slightly low-res like a scan
    img = img.resize((int(w * rng.uniform(0.9, 1.0)),
                      int(h * rng.uniform(0.9, 1.0))), Image.LANCZOS)
    img = img.resize((w, h), Image.LANCZOS)
    return img


def _paste_region(src_img: Image.Image, box) -> Image.Image:
    """Copy a rectangular region and paste it back (copy-move attacker)."""
    x0, y0, x1, y1 = box
    region = src_img.crop(box)
    # scale region up a bit so it's visibly different
    reg = region.resize((int((x1 - x0) * 1.35), int((y1 - y0) * 1.1)),
                        Image.LANCZOS)
    out = src_img.copy()
    # paste at a slightly different location over a text area
    paste_x = min(x0 + 20, out.width - reg.width - 5)
    paste_y = min(y0 - 15, out.height - reg.height - 5)
    out.paste(reg, (paste_x, paste_y))
    return out


def _stamp_overlay(img: Image.Image, rng: random.Random) -> Image.Image:
    """Paste a red verification-style stamp (like an approval seal)."""
    s = 130
    stamp = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ds = ImageDraw.Draw(stamp)
    cx = cy = s // 2
    f_stamp = _font(30)
    ds.ellipse([8, 8, s - 8, s - 8], outline=(200, 30, 30, 220), width=9)
    ds.ellipse([16, 16, s - 16, s - 16], outline=(200, 30, 30, 160), width=3)
    ds.text((cx - 30, cy - 15), "APPROVED", fill=(200, 30, 30, 230), font=f_stamp)
    img = img.convert("RGBA")
    px = int(img.width * rng.uniform(0.45, 0.6))
    py = int(img.height * rng.uniform(0.35, 0.55))
    img.paste(stamp, (px, py), stamp)
    return img.convert("RGB")


def _text_replace(img: Image.Image, rng: random.Random) -> Image.Image:
    """Erase a central region and re-print different text (text replacement)."""
    out = img.copy()
    d = ImageDraw.Draw(out)
    w, h = out.size
    # wipe a text band
    y0 = int(h * 0.45); y1 = y0 + 34
    d.rectangle([30, y0, w - 30, y1], fill=(252, 251, 247))
    # draw a slightly-off new value (typical fraud: change amount/number)
    d.text((34, y0), f"AMOUNT {rng.randint(1, 999)}.{rng.randint(0, 99):02d}",
           fill=(25, 25, 25), font=_font(18))
    return out


def render_fake(doc_type: str, rng: random.Random, i: int) -> Image.Image:
    """Authentic doc + one forgery attack (mixed, mirrors training recipes)."""
    base = render_real(doc_type, rng, i)
    attack = rng.choice(["copy-move", "stamp", "text-replace", "splice",
                         "double-compress", "copy-move", "stamp", "text-replace"])
    if attack == "copy-move":
        w, h = base.size
        return _paste_region(base, (int(w*0.55), int(h*0.35),
                                    int(w*0.75), int(h*0.45)))
    if attack == "stamp":
        return _stamp_overlay(base, rng)
    if attack == "text-replace":
        return _text_replace(base, rng)
    if attack == "splice":
        # paste a block from a different doc
        other = render_real(doc_type, rng, i + 99999)
        w, h = base.size
        reg = other.crop((int(w*0.1), int(h*0.5), int(w*0.5), int(h*0.72)))
        out = base.copy()
        out.paste(reg, (int(w*0.5), int(h*0.5)))
        return out
    # double-compress: re-save at low quality through BytesIO
    if attack == "double-compress":
        import io
        for _ in range(2):
            buf = io.BytesIO()
            base.save(buf, "JPEG", quality=rng.randint(45, 65))
            buf.seek(0)
            base = Image.open(buf).convert("RGB")
        return base
    return base


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out_dir", type=str)
    ap.add_argument("--n", type=int, default=20, help="pairs per doc type")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    out = Path(args.out_dir)
    real_dir = out / "real"
    fake_dir = out / "fake"
    real_dir.mkdir(parents=True, exist_ok=True)
    fake_dir.mkdir(parents=True, exist_ok=True)

    rng = random.Random(args.seed)
    doc_types = ["id", "invoice", "certificate"]
    idx = 0
    for doc_type in doc_types:
        for j in range(args.n):
            idx += 1
            real = render_real(doc_type, rng, idx)
            fake = render_fake(doc_type, rng, idx)
            real.save(real_dir / f"docs_{idx}.jpg", "JPEG", quality=92)
            fake.save(fake_dir / f"docs_{idx}.jpg", "JPEG", quality=92)
    print(f"generated {idx} pairs into {out}")
    print(f"  real: {len(list(real_dir.iterdir()))} images")
    print(f"  fake: {len(list(fake_dir.iterdir()))} images")


if __name__ == "__main__":
    main()