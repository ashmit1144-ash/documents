"""Batch document forgery classifier + renamer (GPU).

Scans a folder for document images, classifies each as REAL or FORGED using
zodumair/document-forgery-detector (ViT-B/16 on ELA-blended input, 224x224),
and renames the files with a `real_` / `fake_` prefix.

Uses the same prep as the app's forensics pipeline:
    ela_blend(img, alpha=0.3) -> ViT processor -> softmax -> forged_prob

Verdict: forged_prob >= 0.5  -> rename to fake_<name>
         forged_prob <  0.5  -> rename to real_<name>

Usage:
    python tools/classify_rename_docs.py <images_dir> [--batch 32] [--dry-run]
"""
from __future__ import annotations

import argparse
import io
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageChops, ImageEnhance

# --- resolve project root so we can import app helpers if present -----------
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

MODEL_REPO = "zodumair/document-forgery-detector"
# Local HF hub snapshot (weights were already downloaded and the remote repo is
# now gated, so we load straight from disk to avoid a 401).
HF_CACHE = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{MODEL_REPO.replace('/', '--')}"
THRESHOLD = 0.5  # >= means FORGED

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def get_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def ela_blend(pil_img: Image.Image, alpha: float = 0.3, quality: int = 90,
              scale: int = 15) -> Image.Image:
    """Original blended with its Error Level Analysis residual."""
    orig = pil_img.convert("RGB")
    buf = io.BytesIO()
    orig.save(buf, "JPEG", quality=quality)
    buf.seek(0)
    diff = ImageChops.difference(orig, Image.open(buf).convert("RGB"))
    ela = ImageEnhance.Brightness(diff).enhance(scale)
    return Image.blend(orig, ela, alpha)


def load_model(device: torch.device):
    from transformers import AutoImageProcessor, AutoModelForImageClassification

    # Resolve a local snapshot dir if present, otherwise fall back to the repo id.
    local_dir = None
    if HF_CACHE.is_dir():
        snaps = list((HF_CACHE / "snapshots").glob("*/"))
        if snaps:
            local_dir = snaps[0]

    ckpt = str(local_dir) if local_dir else MODEL_REPO
    if local_dir:
        print(f"loading model from local cache: {ckpt}")
    else:
        print(f"loading model from hub: {ckpt}")

    proc = AutoImageProcessor.from_pretrained(ckpt)
    model = AutoModelForImageClassification.from_pretrained(ckpt)
    if device.type == "cuda":
        model = model.half()  # FP16 → ~2x throughput on RTX, fits 6GB
    model = model.to(device)
    model.eval()
    return model, proc


def collect_images(folder: Path):
    return sorted(
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() in IMG_EXTS
    )


def run_batch(model, proc, images, device: torch.device, batch_size: int):
    """Run inference over a list of PIL images. Returns forged probabilities."""
    probs = []
    n = len(images)
    for i in range(0, n, batch_size):
        batch_imgs = images[i:i + batch_size]
        blended = [ela_blend(im) for im in batch_imgs]
        inputs = proc(images=blended, return_tensors="pt")
        if device.type == "cuda":
            inputs = {k: v.to(device).half() for k, v in inputs.items()}
        else:
            inputs = {k: v.to(device) for k, v in inputs.items()}
        with torch.no_grad():
            logits = model(**inputs).logits
        p = torch.softmax(logits, dim=-1)
        if device.type == "cuda":
            p = p.cpu()
        p = p.numpy()
        for row in p:
            forged = float(row[1]) if row.shape[0] > 1 else float(row[0])
            probs.append(forged)
    return np.array(probs, dtype=np.float64)


class GpuMonitor(threading.Thread):
    """Samples nvidia-smi GPU util/mem in a background thread."""

    def __init__(self):
        super().__init__(daemon=True)
        self._evt = threading.Event()
        self.util = 0.0
        self.mem_mib = 0

    def run(self):
        import re
        while not self._evt.is_set():
            try:
                out = subprocess.run(
                    ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used",
                     "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=3,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                ).stdout.strip()
                m = re.match(r"([\d.]+),\s+([\d.]+)", out)
                if m:
                    u, mem = float(m.group(1)), int(float(m.group(2)))
                    self.util = max(self.util, u)
                    self.mem_mib = max(self.mem_mib, mem)
                    self._seen += 1
            except Exception:
                pass
            time.sleep(0.25)

    def stop(self):
        self._evt.set()
        self.join(timeout=5)
        return self.util, self.mem_mib


def pick_batch(device: torch.device, n_images: int, requested: int) -> int:
    """Cap the batch to what the GPU can hold (rough heuristic for 6GB)."""
    if device.type == "cpu":
        return requested
    total_mem = torch.cuda.get_device_properties(0).total_memory
    gb = total_mem / (1024 ** 3)
    # ViT-B/16 @224 fp16/32: ~0.35–1.1 GiB per item incl. activations. Stay safe.
    cap = max(8, min(64, int(gb * 18)))
    return min(requested, cap)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("images_dir", type=str, help="folder containing document images")
    ap.add_argument("--batch", type=int, default=32, help="GPU batch size")
    ap.add_argument("--dry-run", action="store_true",
                    help="only print the would-be renames, don't rename")
    ap.add_argument("--threshold", type=float, default=THRESHOLD,
                    help="forged-prob >= threshold -> fake (default 0.5)")
    args = ap.parse_args()

    folder = Path(args.images_dir)
    if not folder.is_dir():
        sys.exit(f"error: not a directory: {folder}")

    images = collect_images(folder)
    if not images:
        sys.exit(f"no image files found in {folder}")

    device = get_device()
    print(f"device: {device}  ({torch.cuda.get_device_name(0) if device.type=='cuda' else 'CPU'})")
    batch = pick_batch(device, len(images), args.batch)
    print(f"images found: {len(images)}   batch: {batch}")

    print("loading ViT model...")
    model, proc = load_model(device)

    # load PILs (ELA prep is done inside run_batch)
    pil_images = [Image.open(p).convert("RGB") for p in images]

    monitor = GpuMonitor() if device.type == "cuda" else None
    if monitor:
        monitor.start()

    t0 = time.time()
    probs = run_batch(model, proc, pil_images, device, batch)
    elapsed = time.time() - t0
    peak_util, peak_mem = monitor.stop() if monitor else (0, 0)
    if monitor:
        print(f"GPU: peak util {peak_util:.0f}%, peak mem {peak_mem} MiB / "
              f"{round(torch.cuda.get_device_properties(0).total_memory/1024**3, 1)} GiB")
    print(f"inference done in {elapsed:.2f}s ({elapsed/max(len(images),1):.3f}s/img)")

    # report
    real_n = fake_n = 0
    renames = []
    for path, p in zip(images, probs):
        verdict = "fake" if p >= args.threshold else "real"
        if verdict == "fake":
            fake_n += 1
        else:
            real_n += 1
        new_name = f"{verdict}_{path.name}"
        renames.append((path, new_name, p, verdict))
        print(f"  {p:6.3f}  -> {new_name}   [{verdict.upper()}]")

    print(f"\nsummary: real={real_n} fake={fake_n} (total {len(images)})")

    if args.dry_run:
        print("dry-run: files NOT renamed.")
        return

    print("renaming files...")
    for path, new_name, p, _ in renames:
        dst = path.with_name(new_name)
        if dst == path:
            continue
        if dst.exists():
            print(f"  SKIP (exists): {new_name}")
            continue
        path.rename(dst)
    print("done.")


if __name__ == "__main__":
    main()
